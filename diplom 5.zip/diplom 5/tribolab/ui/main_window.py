"""Этап 10. Пользовательский интерфейс TriboLab Analyzer."""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from tribolab import __app_name__, __version__
from tribolab.core.pipeline import ProcessedExperiment, build_comparison, process_experiment
from tribolab.core.preprocess import PreprocessConfig, PreprocessResult
from tribolab.core.validator import validate_dataframe
from tribolab.io.loader import load_experiment
from tribolab.report.exporter import export_session
from tribolab.ui.styles import APP_STYLE, PLOT_TITLES
from tribolab.viz.plots import build_plots


def _df_to_table(table: QTableWidget, df: pd.DataFrame, max_rows: int = 300) -> None:
    view = df.head(max_rows)
    table.clear()
    table.setRowCount(len(view))
    table.setColumnCount(len(view.columns))
    table.setHorizontalHeaderLabels([str(c) for c in view.columns])
    table.setAlternatingRowColors(True)
    for r, (_, row) in enumerate(view.iterrows()):
        for c, value in enumerate(row):
            text = "" if pd.isna(value) else str(value)
            table.setItem(r, c, QTableWidgetItem(text))
    table.resizeColumnsToContents()


def _experiment_caption(exp: ProcessedExperiment) -> str:
    meta = exp.source.meta or {}
    parts = [exp.source.name]
    material = meta.get("specimen_material")
    lub = meta.get("lubrication")
    load = meta.get("load_N")
    extras = []
    if material:
        extras.append(str(material))
    if lub:
        extras.append(str(lub))
    if load is not None:
        extras.append(f"{load} Н")
    if extras:
        parts.append("— " + ", ".join(extras))
    return " ".join(parts)


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"{__app_name__} v{__version__}")
        self.resize(1220, 820)
        self.setStyleSheet(APP_STYLE)

        self.current: ProcessedExperiment | None = None
        self.experiments: dict[str, ProcessedExperiment] = {}
        self.processed_many: list[ProcessedExperiment] = []
        self.project_root = Path(__file__).resolve().parents[2]
        self.output_dir = self.project_root / "experiments" / "output"
        self.output_dir.mkdir(parents=True, exist_ok=True)

        root = QWidget()
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(10, 8, 10, 8)
        root_layout.setSpacing(8)

        header = QLabel(f"{__app_name__}")
        header.setObjectName("bannerTitle")
        subtitle = QLabel(
            "Обработка результатов трибологического эксперимента · загрузка → проверка → "
            "расчёты → графики → отчёт"
        )
        subtitle.setObjectName("hintLabel")
        root_layout.addWidget(header)
        root_layout.addWidget(subtitle)

        self.tabs = QTabWidget()
        root_layout.addWidget(self.tabs)
        self.setCentralWidget(root)

        self._build_data_tab()
        self._build_validation_tab()
        self._build_preprocess_tab()
        self._build_calc_tab()
        self._build_plots_tab()
        self._build_compare_tab()
        self._build_report_tab()
        self._build_menu()

        self.statusBar().showMessage("Готово. Откройте файл эксперимента.")

    def _style_button(self, btn: QPushButton, role: str = "default") -> QPushButton:
        mapping = {
            "primary": "btnPrimary",
            "accent": "btnAccent",
            "secondary": "btnSecondary",
            "danger": "btnDanger",
        }
        if role in mapping:
            btn.setObjectName(mapping[role])
        return btn

    # ----- menu -----
    def _build_menu(self) -> None:
        open_act = QAction("Открыть…", self)
        open_act.triggered.connect(self.open_file)
        quit_act = QAction("Выход", self)
        quit_act.triggered.connect(self.close)
        help_act = QAction("О программе", self)
        help_act.triggered.connect(self.show_about)

        menu = self.menuBar()
        file_menu = menu.addMenu("Файл")
        file_menu.addAction(open_act)
        file_menu.addSeparator()
        file_menu.addAction(quit_act)
        help_menu = menu.addMenu("Справка")
        help_menu.addAction(help_act)

    # ----- tabs -----
    def _build_data_tab(self) -> None:
        w = QWidget()
        layout = QVBoxLayout(w)

        btn_row = QHBoxLayout()
        self.btn_open = self._style_button(QPushButton("Открыть файл…"), "primary")
        self.btn_open.clicked.connect(self.open_file)
        self.btn_open_example = self._style_button(
            QPushButton("Открыть пример EXP02"), "secondary"
        )
        self.btn_open_example.clicked.connect(self.open_example)
        self.lbl_file = QLabel("Файл не выбран")
        self.lbl_file.setObjectName("hintLabel")
        btn_row.addWidget(self.btn_open)
        btn_row.addWidget(self.btn_open_example)
        btn_row.addWidget(self.lbl_file, stretch=1)
        layout.addLayout(btn_row)

        self.meta_text = QTextEdit()
        self.meta_text.setReadOnly(True)
        self.meta_text.setMaximumHeight(140)
        layout.addWidget(QLabel("Метаданные / сведения о файле"))
        layout.addWidget(self.meta_text)

        self.data_table = QTableWidget()
        layout.addWidget(QLabel("Превью данных (первые 300 строк)"))
        layout.addWidget(self.data_table)
        self.tabs.addTab(w, "1. Данные")

    def _build_validation_tab(self) -> None:
        w = QWidget()
        layout = QVBoxLayout(w)
        row = QHBoxLayout()
        self.btn_validate = self._style_button(QPushButton("Проверить файл"), "accent")
        self.btn_validate.clicked.connect(self.run_validation_only)
        self.lbl_validation_hint = QLabel(
            "Покажет заголовок файла, пропуски по колонкам и список замечаний."
        )
        self.lbl_validation_hint.setObjectName("hintLabel")
        row.addWidget(self.btn_validate)
        row.addWidget(self.lbl_validation_hint, stretch=1)
        layout.addLayout(row)
        self.validation_text = QTextEdit()
        self.validation_text.setReadOnly(True)
        self.validation_text.setPlaceholderText(
            "Откройте файл и нажмите «Проверить файл» — здесь появится наглядный отчёт."
        )
        layout.addWidget(self.validation_text)
        self.tabs.addTab(w, "2. Проверка")

    def _show_validation_report(self, result=None) -> None:
        if result is None:
            if not self.current:
                return
            result = self.current.validation
        self.validation_text.setHtml(result.to_html())

    def _build_preprocess_tab(self) -> None:
        w = QWidget()
        layout = QVBoxLayout(w)

        form_box = QGroupBox("Параметры обработки")
        form = QFormLayout(form_box)

        self.cmb_outlier = QComboBox()
        self.cmb_outlier.addItems(["iqr", "zscore", "none"])
        self.cmb_outlier_action = QComboBox()
        self.cmb_outlier_action.addItems(["clip", "nan", "remove"])
        self.cmb_smooth = QComboBox()
        self.cmb_smooth.addItems(["moving_average", "median", "none"])
        self.spin_window = QSpinBox()
        self.spin_window.setRange(3, 101)
        self.spin_window.setSingleStep(2)
        self.spin_window.setValue(5)

        self.spin_t_from = QDoubleSpinBox()
        self.spin_t_from.setRange(0, 1_000_000)
        self.spin_t_from.setSpecialValueText("не задано")
        self.spin_t_from.setValue(0)
        self.spin_t_to = QDoubleSpinBox()
        self.spin_t_to.setRange(0, 1_000_000)
        self.spin_t_to.setSpecialValueText("не задано")
        self.spin_t_to.setValue(0)

        self.spin_steady = QDoubleSpinBox()
        self.spin_steady.setRange(0, 1_000_000)
        self.spin_steady.setValue(0)
        self.spin_steady.setSpecialValueText("авто")

        form.addRow("Метод выбросов", self.cmb_outlier)
        form.addRow("Действие с выбросами", self.cmb_outlier_action)
        form.addRow("Сглаживание", self.cmb_smooth)
        form.addRow("Окно сглаживания", self.spin_window)
        form.addRow("Время от, с (0 = нет)", self.spin_t_from)
        form.addRow("Время до, с (0 = нет)", self.spin_t_to)
        form.addRow("Стационар с, с (0 = авто)", self.spin_steady)
        layout.addWidget(form_box)

        self.btn_process = self._style_button(
            QPushButton("Выполнить обработку и расчёты"), "primary"
        )
        self.btn_process.clicked.connect(self.run_full_process)
        layout.addWidget(self.btn_process)

        self.preprocess_text = QTextEdit()
        self.preprocess_text.setReadOnly(True)
        layout.addWidget(QLabel("Протокол обработки"))
        layout.addWidget(self.preprocess_text)
        self.tabs.addTab(w, "3. Обработка")

    def _build_calc_tab(self) -> None:
        w = QWidget()
        layout = QVBoxLayout(w)
        self.calc_text = QTextEdit()
        self.calc_text.setReadOnly(True)
        layout.addWidget(QLabel("Результаты расчёта"))
        layout.addWidget(self.calc_text)
        self.calc_table = QTableWidget()
        layout.addWidget(QLabel("Данные с колонкой μ"))
        layout.addWidget(self.calc_table)
        self.tabs.addTab(w, "4. Расчёты")

    def _build_plots_tab(self) -> None:
        w = QWidget()
        layout = QVBoxLayout(w)

        exp_row = QHBoxLayout()
        exp_row.addWidget(QLabel("Эксперимент:"))
        self.cmb_plot_experiment = QComboBox()
        self.cmb_plot_experiment.setMinimumWidth(360)
        self.cmb_plot_experiment.currentIndexChanged.connect(self.on_plot_experiment_changed)
        exp_row.addWidget(self.cmb_plot_experiment, stretch=1)
        self.btn_plots = self._style_button(
            QPushButton("Построить / обновить графики"), "accent"
        )
        self.btn_plots.clicked.connect(self.build_plots_ui)
        exp_row.addWidget(self.btn_plots)
        layout.addLayout(exp_row)

        self.lbl_plot_experiment_info = QLabel(
            "Выберите эксперимент — здесь появится, к каким данным относятся графики."
        )
        self.lbl_plot_experiment_info.setObjectName("bannerInfo")
        self.lbl_plot_experiment_info.setWordWrap(True)
        layout.addWidget(self.lbl_plot_experiment_info)

        type_row = QHBoxLayout()
        type_row.addWidget(QLabel("Тип графика:"))
        self.cmb_plot = QComboBox()
        self.cmb_plot.currentIndexChanged.connect(self.show_selected_plot)
        type_row.addWidget(self.cmb_plot, stretch=1)
        layout.addLayout(type_row)

        self.plot_label = QLabel("График появится здесь")
        self.plot_label.setObjectName("plotFrame")
        self.plot_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.plot_label.setMinimumHeight(400)
        layout.addWidget(self.plot_label, stretch=1)
        self.tabs.addTab(w, "5. Графики")

    def _build_compare_tab(self) -> None:
        w = QWidget()
        layout = QVBoxLayout(w)
        row = QHBoxLayout()
        self.btn_add_compare = self._style_button(
            QPushButton("Добавить текущий опыт к сравнению"), "secondary"
        )
        self.btn_add_compare.clicked.connect(self.add_to_compare)
        self.btn_compare = self._style_button(
            QPushButton("Сравнить загруженные опыты"), "primary"
        )
        self.btn_compare.clicked.connect(self.run_compare)
        self.btn_clear_compare = self._style_button(QPushButton("Очистить список"), "danger")
        self.btn_clear_compare.clicked.connect(self.clear_compare)
        row.addWidget(self.btn_add_compare)
        row.addWidget(self.btn_compare)
        row.addWidget(self.btn_clear_compare)
        layout.addLayout(row)

        self.compare_list = QTextEdit()
        self.compare_list.setReadOnly(True)
        self.compare_list.setMaximumHeight(100)
        layout.addWidget(QLabel("Опыты в сравнении"))
        layout.addWidget(self.compare_list)

        self.compare_table = QTableWidget()
        layout.addWidget(self.compare_table)

        self.compare_plot_label = QLabel("График сравнения μ")
        self.compare_plot_label.setObjectName("plotFrame")
        self.compare_plot_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.compare_plot_label.setMinimumHeight(280)
        layout.addWidget(self.compare_plot_label)
        self.tabs.addTab(w, "6. Сравнение")

    def _build_report_tab(self) -> None:
        w = QWidget()
        layout = QVBoxLayout(w)
        self.btn_report = self._style_button(
            QPushButton("Сформировать отчёт (Excel + PDF)"), "primary"
        )
        self.btn_report.clicked.connect(self.export_report)
        self.report_text = QTextEdit()
        self.report_text.setReadOnly(True)
        layout.addWidget(self.btn_report)
        layout.addWidget(self.report_text)
        self.tabs.addTab(w, "7. Отчёт")

    # ----- helpers -----
    def _current_preprocess_config(self) -> PreprocessConfig:
        t_from = self.spin_t_from.value()
        t_to = self.spin_t_to.value()
        return PreprocessConfig(
            outlier_method=self.cmb_outlier.currentText(),
            outlier_action=self.cmb_outlier_action.currentText(),
            smooth_method=self.cmb_smooth.currentText(),
            smooth_window=self.spin_window.value(),
            time_from=None if t_from <= 0 else t_from,
            time_to=None if t_to <= 0 else t_to,
        )

    def _steady_from(self) -> float | None:
        value = self.spin_steady.value()
        return None if value <= 0 else value

    def _set_pixmap(self, label: QLabel, path: Path) -> None:
        pix = QPixmap(str(path))
        if pix.isNull():
            label.setText(f"Не удалось отобразить: {path}")
            return
        label.setPixmap(
            pix.scaled(
                max(label.width(), 900),
                max(label.height(), 360),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
        )

    def _register_experiment(self, processed: ProcessedExperiment) -> None:
        """Сохранить обработанный опыт в списке для вкладки графиков."""
        if processed.friction is None:
            return
        self.experiments[processed.source.name] = processed
        self._refresh_plot_experiment_combo(select_name=processed.source.name)

    def _refresh_plot_experiment_combo(self, select_name: str | None = None) -> None:
        current = select_name or self.cmb_plot_experiment.currentData()
        self.cmb_plot_experiment.blockSignals(True)
        self.cmb_plot_experiment.clear()
        for name, exp in self.experiments.items():
            self.cmb_plot_experiment.addItem(_experiment_caption(exp), name)
        # выбрать нужный
        if current:
            idx = self.cmb_plot_experiment.findData(current)
            if idx >= 0:
                self.cmb_plot_experiment.setCurrentIndex(idx)
        self.cmb_plot_experiment.blockSignals(False)
        self.on_plot_experiment_changed()

    def _selected_plot_experiment(self) -> ProcessedExperiment | None:
        name = self.cmb_plot_experiment.currentData()
        if not name:
            return self.current if self.current and self.current.friction else None
        return self.experiments.get(name)

    def _update_plot_experiment_banner(self, exp: ProcessedExperiment | None) -> None:
        if exp is None:
            self.lbl_plot_experiment_info.setText(
                "Нет обработанных экспериментов. Выполните расчёты на вкладке 3 — "
                "тогда опыт появится в списке выше."
            )
            return
        meta = exp.source.meta or {}
        mu = ""
        if exp.summary is not None:
            mu = f"μ<sub>стац</sub> = <b>{exp.summary.mu_mean_steady:.4f}</b>"
        lines = [
            f"<b>Сейчас показаны графики для:</b> {exp.source.name}",
            f"Файл: {exp.source.path.name}",
        ]
        details = []
        for key, title in (
            ("specimen_material", "материал"),
            ("lubrication", "смазка"),
            ("load_N", "нагрузка"),
            ("speed_m_s", "скорость"),
        ):
            if key in meta:
                details.append(f"{title}: {meta[key]}")
        if details:
            lines.append(" · ".join(details))
        if mu:
            lines.append(mu)
        self.lbl_plot_experiment_info.setText("<br>".join(lines))

    # ----- actions -----
    def open_example(self) -> None:
        example = (
            self.project_root
            / "data"
            / "examples"
            / "raw"
            / "EXP02_steel_oil_50N.csv"
        )
        if not example.exists():
            QMessageBox.warning(self, "Нет примера", f"Файл не найден:\n{example}")
            return
        self.load_path(example)

    def open_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Открыть эксперимент",
            str(self.project_root / "data" / "examples" / "raw"),
            "Данные (*.csv *.txt *.xlsx);;Все файлы (*.*)",
        )
        if path:
            self.load_path(Path(path))

    def load_path(self, path: Path) -> None:
        try:
            source = load_experiment(path)
            validation = validate_dataframe(
                source.dataframe,
                filename=path.name,
                meta=source.meta,
            )
            self.current = ProcessedExperiment(
                source=source,
                validation=validation,
                preprocessed=PreprocessResult(
                    dataframe=source.dataframe,
                    steps=["Обработка ещё не выполнялась"],
                ),
            )
            self.lbl_file.setText(str(path))
            df = source.dataframe
            _df_to_table(self.data_table, df)

            meta_lines = [
                f"Файл: {path.name}",
                f"Строк: {len(df)}",
                f"Колонки: {', '.join(map(str, df.columns))}",
            ]
            if source.meta:
                meta_lines.append("")
                meta_lines.append("Метаданные:")
                for k, v in source.meta.items():
                    if k == "units":
                        continue
                    meta_lines.append(f"  {k}: {v}")
            self.meta_text.setText("\n".join(meta_lines))
            self._show_validation_report(validation)
            self.calc_text.clear()
            self.preprocess_text.setText("Нажмите «Выполнить обработку и расчёты» на вкладке 3.")
            self.tabs.setCurrentIndex(0)
            self.statusBar().showMessage(f"Загружено: {path.name}")
        except Exception as exc:
            QMessageBox.critical(self, "Ошибка загрузки", str(exc))

    def run_validation_only(self) -> None:
        if not self.current:
            QMessageBox.information(self, "Нет данных", "Сначала откройте файл.")
            return
        result = validate_dataframe(
            self.current.source.dataframe,
            filename=self.current.source.path.name,
            meta=self.current.source.meta,
        )
        self.current.validation = result
        self._show_validation_report(result)
        self.tabs.setCurrentIndex(1)
        self.statusBar().showMessage(
            "Проверка пройдена" if result.ok else "Проверка выявила ошибки"
        )

    def run_full_process(self) -> None:
        if not self.current:
            QMessageBox.information(self, "Нет данных", "Сначала откройте файл.")
            return
        path = self.current.source.path
        try:
            plots_dir = self.output_dir / path.stem / "plots"
            processed = process_experiment(
                path,
                preprocess_config=self._current_preprocess_config(),
                steady_from_s=self._steady_from(),
                plots_dir=plots_dir,
                allow_invalid=False,
            )
            if not processed.validation.ok:
                processed.validation = validate_dataframe(
                    processed.source.dataframe,
                    filename=processed.source.path.name,
                    meta=processed.source.meta,
                )
                self._show_validation_report(processed.validation)
                QMessageBox.warning(
                    self,
                    "Файл не прошёл проверку",
                    "Исправьте данные или выберите другой файл.\n\n"
                    + processed.validation.to_text(),
                )
                self.tabs.setCurrentIndex(1)
                return

            self.current = processed
            self._register_experiment(processed)
            self.preprocess_text.setText("\n".join(processed.preprocessed.steps))
            if processed.summary and processed.friction and processed.wear:
                lines = [f"{k}: {v}" for k, v in processed.summary.to_rows()]
                lines.append("")
                lines.append(f"Износ: {processed.wear.note}")
                self.calc_text.setText("\n".join(lines))
                _df_to_table(self.calc_table, processed.dataframe)
            self.tabs.setCurrentIndex(3)
            self.statusBar().showMessage(
                f"Готово: {processed.source.name}. Графики — на вкладке 5."
            )
        except Exception as exc:
            QMessageBox.critical(self, "Ошибка обработки", str(exc))

    def on_plot_experiment_changed(self) -> None:
        exp = self._selected_plot_experiment()
        self._update_plot_experiment_banner(exp)
        self._fill_plot_type_combo(exp)
        self.show_selected_plot()

    def _fill_plot_type_combo(self, exp: ProcessedExperiment | None) -> None:
        self.cmb_plot.blockSignals(True)
        self.cmb_plot.clear()
        if exp and exp.plots:
            for key, path in exp.plots.paths.items():
                title = PLOT_TITLES.get(key, key)
                self.cmb_plot.addItem(title, str(path))
        self.cmb_plot.blockSignals(False)

    def build_plots_ui(self) -> None:
        exp = self._selected_plot_experiment()
        if exp is None or exp.friction is None:
            QMessageBox.information(
                self,
                "Нет расчётов",
                "Сначала выполните обработку и расчёты хотя бы для одного опыта.",
            )
            return
        plots_dir = self.output_dir / exp.source.name / "plots"
        exp.plots = build_plots(exp.dataframe, plots_dir, prefix=exp.source.name)
        self.experiments[exp.source.name] = exp
        if self.current and self.current.source.name == exp.source.name:
            self.current = exp
        self._fill_plot_type_combo(exp)
        self._update_plot_experiment_banner(exp)
        self.show_selected_plot()
        self.tabs.setCurrentIndex(4)
        self.statusBar().showMessage(
            f"Графики для «{exp.source.name}» сохранены в {plots_dir}"
        )

    def show_selected_plot(self) -> None:
        path = self.cmb_plot.currentData()
        if not path:
            self.plot_label.setText("Для выбранного эксперимента графиков пока нет.")
            return
        self._set_pixmap(self.plot_label, Path(path))

    def add_to_compare(self) -> None:
        if not self.current or self.current.summary is None:
            QMessageBox.information(self, "Нет расчётов", "Сначала выполните расчёты для опыта.")
            return
        self.processed_many = [
            p for p in self.processed_many if p.source.name != self.current.source.name
        ]
        self.processed_many.append(self.current)
        self._register_experiment(self.current)
        self.compare_list.setText(
            "\n".join(f"• {_experiment_caption(p)}" for p in self.processed_many)
        )
        self.statusBar().showMessage(f"В сравнении: {len(self.processed_many)} опыт(ов)")

    def clear_compare(self) -> None:
        self.processed_many.clear()
        self.compare_list.clear()
        self.compare_table.clear()
        self.compare_plot_label.setText("График сравнения μ")

    def run_compare(self) -> None:
        if len(self.processed_many) < 2:
            QMessageBox.information(
                self, "Мало опытов", "Добавьте минимум два обработанных опыта."
            )
            return
        out = self.output_dir / "comparison"
        out.mkdir(parents=True, exist_ok=True)
        table, plot = build_comparison(
            self.processed_many, plot_path=out / "mu_comparison.png"
        )
        _df_to_table(self.compare_table, table, max_rows=100)
        if plot:
            self._set_pixmap(self.compare_plot_label, plot)
        self.tabs.setCurrentIndex(5)
        self.statusBar().showMessage("Сравнение выполнено")

    def export_report(self) -> None:
        if not self.current or self.current.summary is None or self.current.friction is None:
            QMessageBox.information(self, "Нет расчётов", "Сначала выполните обработку и расчёты.")
            return
        report_dir = self.output_dir / self.current.source.name / "report"
        plots = self.current.plots.as_list() if self.current.plots else []
        compare_table = None
        if len(self.processed_many) >= 2:
            compare_table, _ = build_comparison(self.processed_many)
        try:
            paths = export_session(
                report_dir,
                summary=self.current.summary,
                dataframe=self.current.dataframe,
                preprocess_steps=self.current.preprocessed.steps,
                plot_paths=plots,
                compare_table=compare_table,
            )
            text = "Отчёт сформирован:\n" + "\n".join(f"{k}: {v}" for k, v in paths.items())
            self.report_text.setText(text)
            self.tabs.setCurrentIndex(6)
            QMessageBox.information(self, "Готово", text)
        except Exception as exc:
            QMessageBox.critical(self, "Ошибка отчёта", str(exc))

    def show_about(self) -> None:
        QMessageBox.about(
            self,
            "О программе",
            f"<b>{__app_name__}</b> v{__version__}<br><br>"
            "Программа обработки результатов трибологического эксперимента.<br>"
            "Загрузка данных, проверка, предобработка, расчёт μ и износа, "
            "графики, сравнение опытов, экспорт отчёта.",
        )


def run_app() -> int:
    app = QApplication.instance() or QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    return app.exec()
