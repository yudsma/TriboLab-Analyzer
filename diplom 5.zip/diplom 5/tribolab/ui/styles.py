"""Стили интерфейса TriboLab Analyzer."""

APP_STYLE = """
QMainWindow, QWidget {
    background-color: #eef2f6;
    color: #1a2332;
    font-family: "Segoe UI", "Arial", sans-serif;
    font-size: 13px;
}

QMenuBar {
    background: #1f3a5f;
    color: white;
    padding: 4px;
}
QMenuBar::item:selected {
    background: #2d5a87;
}
QMenu {
    background: #ffffff;
    border: 1px solid #c5d0dc;
}
QMenu::item:selected {
    background: #d6e6f5;
    color: #1a2332;
}

QStatusBar {
    background: #1f3a5f;
    color: #e8eef5;
}

QTabWidget::pane {
    border: 1px solid #c5d0dc;
    background: #ffffff;
    border-radius: 6px;
    top: -1px;
}
QTabBar::tab {
    background: #d9e2ec;
    color: #334e68;
    padding: 9px 16px;
    margin-right: 3px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    font-weight: 600;
}
QTabBar::tab:selected {
    background: #ffffff;
    color: #0b6e4f;
    border-bottom: 3px solid #0b6e4f;
}
QTabBar::tab:hover:!selected {
    background: #cdd9e5;
}

QGroupBox {
    background: #ffffff;
    border: 1px solid #c5d0dc;
    border-radius: 8px;
    margin-top: 12px;
    padding: 12px 10px 10px 10px;
    font-weight: 600;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 12px;
    padding: 0 6px;
    color: #1f3a5f;
}

QTextEdit, QTableWidget, QComboBox, QSpinBox, QDoubleSpinBox {
    background: #ffffff;
    border: 1px solid #b8c4d1;
    border-radius: 6px;
    padding: 4px 6px;
    selection-background-color: #9fd3c0;
}
QComboBox:hover, QSpinBox:hover, QDoubleSpinBox:hover {
    border-color: #0b6e4f;
}
QHeaderView::section {
    background: #1f3a5f;
    color: white;
    padding: 6px;
    border: none;
    font-weight: 600;
}
QTableWidget {
    gridline-color: #d7e0ea;
    alternate-background-color: #f5f8fb;
}

QPushButton {
    background: #3d5a80;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 9px 16px;
    font-weight: 600;
    min-height: 20px;
}
QPushButton:hover {
    background: #4a6d99;
}
QPushButton:pressed {
    background: #2f4663;
}

QPushButton#btnPrimary {
    background: #0b6e4f;
}
QPushButton#btnPrimary:hover {
    background: #0f8a63;
}
QPushButton#btnPrimary:pressed {
    background: #08553c;
}

QPushButton#btnAccent {
    background: #c45c26;
}
QPushButton#btnAccent:hover {
    background: #d46b34;
}
QPushButton#btnAccent:pressed {
    background: #a34b1d;
}

QPushButton#btnSecondary {
    background: #5c7cfa;
}
QPushButton#btnSecondary:hover {
    background: #748ffc;
}

QPushButton#btnDanger {
    background: #c92a2a;
}
QPushButton#btnDanger:hover {
    background: #e03131;
}

QLabel#bannerTitle {
    font-size: 16px;
    font-weight: 700;
    color: #1f3a5f;
}
QLabel#bannerInfo {
    background: #e3f5ee;
    border: 1px solid #9fd3c0;
    border-left: 5px solid #0b6e4f;
    border-radius: 6px;
    padding: 10px 12px;
    color: #1a2332;
}
QLabel#plotFrame {
    background: #ffffff;
    border: 1px solid #c5d0dc;
    border-radius: 8px;
}
QLabel#hintLabel {
    color: #486581;
}
"""

PLOT_TITLES = {
    "friction": "Сила трения — время",
    "mu": "Коэффициент трения μ — время",
    "temperature": "Температура — время",
    "wear": "Износ — время",
}
