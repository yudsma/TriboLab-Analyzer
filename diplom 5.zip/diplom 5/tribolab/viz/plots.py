"""Этап 7. Построение графиков."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


@dataclass
class PlotBundle:
    paths: dict[str, Path] = field(default_factory=dict)

    def as_list(self) -> list[Path]:
        return list(self.paths.values())


def _save(fig: plt.Figure, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=140)
    plt.close(fig)
    return path


def build_plots(
    df: pd.DataFrame,
    out_dir: str | Path,
    *,
    prefix: str = "plot",
) -> PlotBundle:
    """Построить стандартный набор графиков для одного опыта."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    t = pd.to_numeric(df["time_s"], errors="coerce") if "time_s" in df.columns else df.index
    bundle = PlotBundle()

    if "friction_force_N" in df.columns:
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.plot(t, df["friction_force_N"], color="#1f4e79", linewidth=1.0)
        ax.set_xlabel("Время, с")
        ax.set_ylabel("Сила трения, Н")
        ax.set_title("Сила трения — время")
        ax.grid(True, alpha=0.3)
        bundle.paths["friction"] = _save(fig, out_dir / f"{prefix}_friction.png")

    if "mu" in df.columns:
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.plot(t, df["mu"], color="#c45c26", linewidth=1.0)
        ax.set_xlabel("Время, с")
        ax.set_ylabel("Коэффициент трения μ")
        ax.set_title("Коэффициент трения — время")
        ax.grid(True, alpha=0.3)
        bundle.paths["mu"] = _save(fig, out_dir / f"{prefix}_mu.png")

    if "temperature_C" in df.columns:
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.plot(t, df["temperature_C"], color="#2e7d32", linewidth=1.0)
        ax.set_xlabel("Время, с")
        ax.set_ylabel("Температура, °C")
        ax.set_title("Температура — время")
        ax.grid(True, alpha=0.3)
        bundle.paths["temperature"] = _save(fig, out_dir / f"{prefix}_temperature.png")

    if "wear_um" in df.columns:
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.plot(t, df["wear_um"], color="#6a1b9a", linewidth=1.0)
        ax.set_xlabel("Время, с")
        ax.set_ylabel("Износ, мкм")
        ax.set_title("Износ — время")
        ax.grid(True, alpha=0.3)
        bundle.paths["wear"] = _save(fig, out_dir / f"{prefix}_wear.png")

    return bundle


def plot_mu_comparison(
    series_map: dict[str, pd.DataFrame],
    out_path: str | Path,
) -> Path:
    """Наложить кривые μ(t) нескольких опытов."""
    out_path = Path(out_path)
    fig, ax = plt.subplots(figsize=(9, 4.5))
    for name, df in series_map.items():
        if "mu" not in df.columns or "time_s" not in df.columns:
            continue
        ax.plot(
            pd.to_numeric(df["time_s"], errors="coerce"),
            pd.to_numeric(df["mu"], errors="coerce"),
            linewidth=1.0,
            label=name,
        )
    ax.set_xlabel("Время, с")
    ax.set_ylabel("Коэффициент трения μ")
    ax.set_title("Сравнение коэффициента трения")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    return _save(fig, out_path)
