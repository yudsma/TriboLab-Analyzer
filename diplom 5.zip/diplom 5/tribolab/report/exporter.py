"""Этап 9. Формирование и экспорт отчётов."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from tribolab.core.stats import ExperimentSummary

_FONT_REGISTERED = False
_FONT_NAME = "Helvetica"
_FONT_BOLD = "Helvetica-Bold"


def _ensure_fonts() -> None:
    global _FONT_REGISTERED, _FONT_NAME, _FONT_BOLD
    if _FONT_REGISTERED:
        return
    candidates = []
    if os.name == "nt":
        windir = Path(os.environ.get("WINDIR", r"C:\Windows"))
        candidates.extend(
            [
                windir / "Fonts" / "arial.ttf",
                windir / "Fonts" / "Arial.ttf",
                windir / "Fonts" / "times.ttf",
                windir / "Fonts" / "timesi.ttf",
            ]
        )
    candidates.extend(
        [
            Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
            Path("/usr/share/fonts/truetype/freefont/FreeSans.ttf"),
        ]
    )
    for font_path in candidates:
        if font_path.exists():
            try:
                pdfmetrics.registerFont(TTFont("TriboFont", str(font_path)))
                # для bold попробуем arialbd
                bold = font_path.with_name(
                    font_path.name.replace("arial", "arialbd").replace("Arial", "arialbd")
                )
                if not bold.exists():
                    bold = font_path.parent / "arialbd.ttf"
                if bold.exists():
                    pdfmetrics.registerFont(TTFont("TriboFont-Bold", str(bold)))
                    _FONT_BOLD = "TriboFont-Bold"
                else:
                    _FONT_BOLD = "TriboFont"
                _FONT_NAME = "TriboFont"
                break
            except Exception:
                continue
    _FONT_REGISTERED = True


def export_excel_report(
    path: str | Path,
    *,
    summary: ExperimentSummary,
    dataframe: pd.DataFrame,
    preprocess_steps: list[str] | None = None,
    compare_table: pd.DataFrame | None = None,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    metrics = pd.DataFrame(summary.to_rows(), columns=["Показатель", "Значение"])
    steps = pd.DataFrame({"Шаг обработки": preprocess_steps or ["—"]})

    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        metrics.to_excel(writer, sheet_name="Метрики", index=False)
        dataframe.to_excel(writer, sheet_name="Данные", index=False)
        steps.to_excel(writer, sheet_name="Обработка", index=False)
        if compare_table is not None and not compare_table.empty:
            compare_table.to_excel(writer, sheet_name="Сравнение", index=False)
        if summary.meta:
            meta_df = pd.DataFrame(
                [{"Параметр": k, "Значение": str(v)} for k, v in summary.meta.items()]
            )
            meta_df.to_excel(writer, sheet_name="Метаданные", index=False)
    return path


def export_pdf_report(
    path: str | Path,
    *,
    summary: ExperimentSummary,
    plot_paths: list[Path] | None = None,
    preprocess_steps: list[str] | None = None,
) -> Path:
    _ensure_fonts()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "TriboTitle",
        parent=styles["Title"],
        fontName=_FONT_BOLD,
        fontSize=16,
    )
    h2 = ParagraphStyle(
        "TriboH2",
        parent=styles["Heading2"],
        fontName=_FONT_BOLD,
        fontSize=13,
    )
    h3 = ParagraphStyle(
        "TriboH3",
        parent=styles["Heading3"],
        fontName=_FONT_BOLD,
        fontSize=11,
    )
    body = ParagraphStyle(
        "TriboBody",
        parent=styles["Normal"],
        fontName=_FONT_NAME,
        fontSize=10,
        leading=13,
    )

    doc = SimpleDocTemplate(
        str(path),
        pagesize=A4,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
        topMargin=1.5 * cm,
        bottomMargin=1.5 * cm,
    )
    story: list[Any] = []
    story.append(Paragraph("Отчёт TriboLab Analyzer", title_style))
    story.append(Paragraph(f"Опыт: {summary.name}", h2))
    story.append(Spacer(1, 0.3 * cm))

    if summary.meta:
        story.append(Paragraph("Параметры опыта", h3))
        for key in (
            "specimen_material",
            "counterbody_material",
            "lubrication",
            "load_N",
            "speed_m_s",
            "machine_type",
            "date",
            "operator",
        ):
            if key in summary.meta:
                story.append(Paragraph(f"<b>{key}</b>: {summary.meta[key]}", body))
        story.append(Spacer(1, 0.3 * cm))

    story.append(Paragraph("Результаты расчёта", h3))
    table_data = [["Показатель", "Значение"]] + [list(r) for r in summary.to_rows()]
    table = Table(table_data, colWidths=[8 * cm, 7 * cm])
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f4e79")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
                ("FONTNAME", (0, 0), (-1, 0), _FONT_BOLD),
                ("FONTNAME", (0, 1), (-1, -1), _FONT_NAME),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.lightgrey]),
            ]
        )
    )
    story.append(table)
    story.append(Spacer(1, 0.4 * cm))

    if preprocess_steps:
        story.append(Paragraph("Применённая обработка", h3))
        for step in preprocess_steps:
            story.append(Paragraph(f"• {step}", body))
        story.append(Spacer(1, 0.3 * cm))

    if plot_paths:
        story.append(Paragraph("Графики", h3))
        for p in plot_paths:
            if Path(p).exists():
                story.append(Spacer(1, 0.2 * cm))
                story.append(Image(str(p), width=16 * cm, height=8 * cm))

    doc.build(story)
    return path


def export_session(
    out_dir: str | Path,
    *,
    summary: ExperimentSummary,
    dataframe: pd.DataFrame,
    preprocess_steps: list[str] | None = None,
    plot_paths: list[Path] | None = None,
    compare_table: pd.DataFrame | None = None,
) -> dict[str, Path]:
    """Сохранить полный комплект артефактов опыта."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    excel = export_excel_report(
        out_dir / f"{summary.name}_report.xlsx",
        summary=summary,
        dataframe=dataframe,
        preprocess_steps=preprocess_steps,
        compare_table=compare_table,
    )
    pdf = export_pdf_report(
        out_dir / f"{summary.name}_report.pdf",
        summary=summary,
        plot_paths=plot_paths,
        preprocess_steps=preprocess_steps,
    )
    return {"excel": excel, "pdf": pdf}
