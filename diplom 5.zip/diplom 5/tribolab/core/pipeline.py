"""Сценарий полной обработки одного эксперимента."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pandas as pd

from tribolab.core.compare import compare_experiments
from tribolab.core.friction import FrictionResult, calculate_friction
from tribolab.core.preprocess import PreprocessConfig, PreprocessResult, preprocess
from tribolab.core.stats import ExperimentSummary, summarize_experiment
from tribolab.core.validator import ValidationResult, validate_dataframe
from tribolab.core.wear import WearResult, calculate_wear
from tribolab.io.loader import ExperimentData, load_experiment
from tribolab.report.exporter import export_session
from tribolab.viz.plots import PlotBundle, build_plots, plot_mu_comparison


@dataclass
class ProcessedExperiment:
    source: ExperimentData
    validation: ValidationResult
    preprocessed: PreprocessResult
    friction: FrictionResult | None = None
    wear: WearResult | None = None
    summary: ExperimentSummary | None = None
    plots: PlotBundle | None = None
    export_paths: dict[str, Path] = field(default_factory=dict)

    @property
    def dataframe(self) -> pd.DataFrame:
        if self.friction is not None:
            return self.friction.dataframe
        return self.preprocessed.dataframe


def process_experiment(
    path: str | Path,
    *,
    preprocess_config: PreprocessConfig | None = None,
    steady_from_s: float | None = None,
    plots_dir: str | Path | None = None,
    export_dir: str | Path | None = None,
    allow_invalid: bool = False,
) -> ProcessedExperiment:
    """Полный конвейер: загрузка → проверка → обработка → расчёты → графики/отчёт."""
    source = load_experiment(path)
    validation = validate_dataframe(
        source.dataframe,
        filename=Path(path).name,
        meta=source.meta,
    )
    if not validation.ok and not allow_invalid:
        return ProcessedExperiment(
            source=source,
            validation=validation,
            preprocessed=PreprocessResult(dataframe=source.dataframe, steps=["Не выполнялась из-за ошибок"]),
        )

    prep = preprocess(source.dataframe, preprocess_config)
    friction = calculate_friction(prep.dataframe, steady_from_s=steady_from_s)
    wear = calculate_wear(friction.dataframe)
    summary = summarize_experiment(
        source.name,
        friction.dataframe,
        friction,
        wear,
        meta=source.meta,
    )

    plots = None
    export_paths: dict[str, Path] = {}
    if plots_dir is not None:
        plots = build_plots(friction.dataframe, plots_dir, prefix=source.name)
    if export_dir is not None:
        export_paths = export_session(
            export_dir,
            summary=summary,
            dataframe=friction.dataframe,
            preprocess_steps=prep.steps,
            plot_paths=plots.as_list() if plots else None,
        )

    return ProcessedExperiment(
        source=source,
        validation=validation,
        preprocessed=prep,
        friction=friction,
        wear=wear,
        summary=summary,
        plots=plots,
        export_paths=export_paths,
    )


def build_comparison(
    processed: list[ProcessedExperiment],
    *,
    plot_path: str | Path | None = None,
) -> tuple[pd.DataFrame, Path | None]:
    summaries = [p.summary for p in processed if p.summary is not None]
    table = compare_experiments(summaries)
    comparison_plot = None
    if plot_path is not None:
        series_map = {
            p.source.name: p.dataframe
            for p in processed
            if p.friction is not None and "mu" in p.dataframe.columns
        }
        if series_map:
            comparison_plot = plot_mu_comparison(series_map, plot_path)
    return table, comparison_plot
