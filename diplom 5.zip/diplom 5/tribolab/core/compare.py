"""Этап 8. Сравнение результатов нескольких экспериментов."""

from __future__ import annotations

import pandas as pd

from .stats import ExperimentSummary


def compare_experiments(summaries: list[ExperimentSummary]) -> pd.DataFrame:
    """Сводная таблица сравнения ключевых метрик."""
    rows = []
    for s in summaries:
        meta = s.meta or {}
        rows.append(
            {
                "experiment": s.name,
                "material": meta.get("specimen_material", ""),
                "lubrication": meta.get("lubrication", ""),
                "load_N": meta.get("load_N", s.load_mean_N),
                "mu_mean": round(s.mu_mean, 4),
                "mu_steady": round(s.mu_mean_steady, 4),
                "mu_std": round(s.mu_std, 4),
                "wear_delta_um": None if s.wear_delta_um is None else round(s.wear_delta_um, 4),
                "wear_rate_um_per_s": None
                if s.wear_rate_um_per_s is None
                else round(s.wear_rate_um_per_s, 6),
                "temp_max_C": None if s.temp_max_C is None else round(s.temp_max_C, 2),
                "n_points": s.n_points,
            }
        )
    return pd.DataFrame(rows)
