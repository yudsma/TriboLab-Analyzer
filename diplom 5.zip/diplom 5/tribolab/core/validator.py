"""Этап 2. Проверка корректности исходных файлов."""

from __future__ import annotations

from dataclasses import dataclass, field
from html import escape
from typing import Any

import numpy as np
import pandas as pd

from tribolab.io.loader import OPTIONAL_COLUMNS, REQUIRED_COLUMNS

COLUMN_TITLES = {
    "time_s": "Время",
    "friction_force_N": "Сила трения",
    "load_N": "Нагрузка",
    "temperature_C": "Температура",
    "wear_um": "Износ",
    "distance_m": "Путь трения",
    "speed_m_s": "Скорость",
}

COLUMN_UNITS = {
    "time_s": "с",
    "friction_force_N": "Н",
    "load_N": "Н",
    "temperature_C": "°C",
    "wear_um": "мкм",
    "distance_m": "м",
    "speed_m_s": "м/с",
}


@dataclass
class ColumnProfile:
    name: str
    title: str
    units: str
    required: bool
    present: bool
    count: int = 0
    missing: int = 0
    missing_share: float = 0.0
    min_value: float | None = None
    max_value: float | None = None
    mean_value: float | None = None


@dataclass
class ValidationIssue:
    level: str  # "error" | "warning"
    code: str
    message: str


@dataclass
class ValidationResult:
    ok: bool
    issues: list[ValidationIssue] = field(default_factory=list)
    n_rows: int = 0
    n_cols: int = 0
    columns: list[str] = field(default_factory=list)
    profiles: list[ColumnProfile] = field(default_factory=list)
    filename: str = ""
    description: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def errors(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.level == "error"]

    @property
    def warnings(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.level == "warning"]

    def to_text(self) -> str:
        lines = [
            "══════════════════════════════════════",
            "  ОТЧЁТ ПРОВЕРКИ ФАЙЛА",
            "══════════════════════════════════════",
        ]
        if self.filename:
            lines.append(f"Файл: {self.filename}")
        if self.description:
            lines.append(f"Описание: {self.description}")
        lines.append(f"Строк: {self.n_rows}   Колонок: {self.n_cols}")
        lines.append(
            f"Итог: {'ПРОЙДЕНО (можно считать)' if self.ok else 'НЕ ПРОЙДЕНО (есть ошибки)'}"
        )
        lines.append("")
        lines.append("--- Заголовок (колонки) ---")
        if self.columns:
            lines.append(", ".join(self.columns))
        else:
            lines.append("(нет колонок)")
        lines.append("")
        lines.append("--- Пропуски и диапазоны по колонкам ---")
        if self.profiles:
            for p in self.profiles:
                req = "обяз." if p.required else "опц."
                if not p.present:
                    lines.append(f"• {p.name} [{req}] — ОТСУТСТВУЕТ")
                    continue
                rng = ""
                if p.min_value is not None and p.max_value is not None:
                    rng = f"  min={p.min_value:.4g}  max={p.max_value:.4g}  mean={p.mean_value:.4g}"
                miss = f"{p.missing} шт. ({p.missing_share:.2%})"
                status = "OK" if p.missing == 0 else "ЕСТЬ ПРОПУСКИ"
                lines.append(
                    f"• {p.title} ({p.name}), {p.units} [{req}] — {status}: {miss}{rng}"
                )
        else:
            lines.append("(нет данных)")
        lines.append("")
        lines.append("--- Замечания ---")
        if not self.issues:
            lines.append("Замечаний нет.")
        else:
            for issue in self.issues:
                prefix = "ОШИБКА" if issue.level == "error" else "ПРЕДУПРЕЖДЕНИЕ"
                lines.append(f"[{prefix}] {issue.message}")
        return "\n".join(lines)

    def to_html(self) -> str:
        status_color = "#2e7d32" if self.ok else "#c62828"
        status_bg = "#e8f5e9" if self.ok else "#ffebee"
        status_text = (
            "ПРОВЕРКА ПРОЙДЕНА — можно выполнять расчёты"
            if self.ok
            else "ПРОВЕРКА НЕ ПРОЙДЕНА — есть блокирующие ошибки"
        )

        parts: list[str] = [
            "<div style='font-family:Segoe UI,Arial,sans-serif; font-size:13px;'>",
            f"<div style='background:{status_bg}; border-left:6px solid {status_color}; "
            f"padding:12px 14px; margin-bottom:12px;'>"
            f"<div style='font-size:18px; font-weight:700; color:{status_color};'>{escape(status_text)}</div>",
        ]
        if self.filename:
            parts.append(f"<div style='margin-top:6px;'><b>Файл:</b> {escape(self.filename)}</div>")
        if self.description:
            parts.append(
                f"<div style='margin-top:4px;'><b>Описание:</b> {escape(self.description)}</div>"
            )
        parts.append(
            f"<div style='margin-top:4px;'><b>Строк:</b> {self.n_rows} &nbsp;|&nbsp; "
            f"<b>Колонок:</b> {self.n_cols} &nbsp;|&nbsp; "
            f"<b>Ошибок:</b> {len(self.errors)} &nbsp;|&nbsp; "
            f"<b>Предупреждений:</b> {len(self.warnings)}</div>"
        )
        parts.append("</div>")

        # meta short
        if self.meta:
            interesting = [
                ("specimen_material", "Материал образца"),
                ("counterbody_material", "Контртело"),
                ("lubrication", "Смазка"),
                ("load_N", "Нагрузка, Н"),
                ("speed_m_s", "Скорость, м/с"),
                ("machine_type", "Машина"),
                ("date", "Дата"),
                ("operator", "Оператор"),
            ]
            meta_rows = []
            for key, title in interesting:
                if key in self.meta:
                    meta_rows.append(
                        f"<tr><td style='padding:3px 8px;'><b>{escape(title)}</b></td>"
                        f"<td style='padding:3px 8px;'>{escape(str(self.meta[key]))}</td></tr>"
                    )
            if meta_rows:
                parts.append("<h3 style='margin:10px 0 6px;'>Паспорт опыта</h3>")
                parts.append(
                    "<table style='border-collapse:collapse; background:#fafafa;'>"
                    + "".join(meta_rows)
                    + "</table>"
                )

        # header columns
        parts.append("<h3 style='margin:14px 0 6px;'>Заголовок файла (колонки)</h3>")
        if self.columns:
            chips = []
            required_set = set(REQUIRED_COLUMNS)
            for col in self.columns:
                is_req = col in required_set
                bg = "#e3f2fd" if is_req else "#f3e5f5"
                tag = "обяз." if is_req else "опц."
                chips.append(
                    f"<span style='display:inline-block; background:{bg}; "
                    f"border:1px solid #bbb; border-radius:4px; padding:3px 8px; "
                    f"margin:2px 4px 2px 0;'>{escape(col)} <small>({tag})</small></span>"
                )
            parts.append("<div>" + "".join(chips) + "</div>")
        else:
            parts.append("<p>Колонки не найдены.</p>")

        # missing table
        parts.append("<h3 style='margin:14px 0 6px;'>Пропуски и диапазоны по колонкам</h3>")
        parts.append(
            "<table style='border-collapse:collapse; width:100%;'>"
            "<tr style='background:#1f4e79; color:white;'>"
            "<th style='padding:6px; text-align:left;'>Колонка</th>"
            "<th style='padding:6px;'>Тип</th>"
            "<th style='padding:6px;'>Пропуски</th>"
            "<th style='padding:6px;'>Доля</th>"
            "<th style='padding:6px;'>Min</th>"
            "<th style='padding:6px;'>Max</th>"
            "<th style='padding:6px;'>Mean</th>"
            "<th style='padding:6px;'>Статус</th>"
            "</tr>"
        )
        for i, p in enumerate(self.profiles):
            bg = "#ffffff" if i % 2 == 0 else "#f5f5f5"
            req = "обяз." if p.required else "опц."
            if not p.present:
                parts.append(
                    f"<tr style='background:#ffebee;'>"
                    f"<td style='padding:6px;'><b>{escape(p.title)}</b><br>"
                    f"<small>{escape(p.name)}</small></td>"
                    f"<td style='padding:6px; text-align:center;'>{req}</td>"
                    f"<td colspan='5' style='padding:6px; text-align:center;'>колонка отсутствует</td>"
                    f"<td style='padding:6px; text-align:center; color:#c62828;'><b>НЕТ</b></td>"
                    f"</tr>"
                )
                continue
            if p.missing == 0:
                status = "<span style='color:#2e7d32; font-weight:700;'>OK</span>"
                miss_bg = bg
            elif p.required and p.missing_share > 0.05:
                status = "<span style='color:#c62828; font-weight:700;'>КРИТИЧНО</span>"
                miss_bg = "#ffebee"
            else:
                status = "<span style='color:#ef6c00; font-weight:700;'>ПРОПУСКИ</span>"
                miss_bg = "#fff8e1"
            units = f", {p.units}" if p.units else ""
            parts.append(
                f"<tr style='background:{miss_bg};'>"
                f"<td style='padding:6px;'><b>{escape(p.title)}</b>{escape(units)}<br>"
                f"<small>{escape(p.name)}</small></td>"
                f"<td style='padding:6px; text-align:center;'>{req}</td>"
                f"<td style='padding:6px; text-align:center;'>{p.missing} / {p.count}</td>"
                f"<td style='padding:6px; text-align:center;'>{p.missing_share:.2%}</td>"
                f"<td style='padding:6px; text-align:center;'>"
                f"{'' if p.min_value is None else f'{p.min_value:.4g}'}</td>"
                f"<td style='padding:6px; text-align:center;'>"
                f"{'' if p.max_value is None else f'{p.max_value:.4g}'}</td>"
                f"<td style='padding:6px; text-align:center;'>"
                f"{'' if p.mean_value is None else f'{p.mean_value:.4g}'}</td>"
                f"<td style='padding:6px; text-align:center;'>{status}</td>"
                f"</tr>"
            )
        parts.append("</table>")

        # issues
        parts.append("<h3 style='margin:14px 0 6px;'>Замечания</h3>")
        if not self.issues:
            parts.append(
                "<div style='background:#e8f5e9; padding:10px; border-radius:4px;'>"
                "Замечаний нет. Файл корректен.</div>"
            )
        else:
            for issue in self.issues:
                if issue.level == "error":
                    color, bg, label = "#c62828", "#ffebee", "ОШИБКА"
                else:
                    color, bg, label = "#ef6c00", "#fff8e1", "ПРЕДУПРЕЖДЕНИЕ"
                parts.append(
                    f"<div style='background:{bg}; border-left:5px solid {color}; "
                    f"padding:8px 10px; margin:6px 0;'>"
                    f"<b style='color:{color};'>[{label}]</b> {escape(issue.message)}"
                    f"</div>"
                )

        parts.append(
            "<div style='margin-top:14px; color:#666; font-size:12px;'>"
            "<b>Подсказка:</b> предупреждения не блокируют расчёт. "
            "Пропуски обычно устраняются на вкладке «3. Обработка» (интерполяция). "
            "Ошибки нужно исправить в исходном файле."
            "</div>"
        )
        parts.append("</div>")
        return "".join(parts)


def _profile_columns(df: pd.DataFrame) -> list[ColumnProfile]:
    profiles: list[ColumnProfile] = []
    known = list(REQUIRED_COLUMNS) + [c for c in OPTIONAL_COLUMNS if c not in REQUIRED_COLUMNS]
    # сначала известные, потом прочие из файла
    extra = [c for c in df.columns if c not in known]
    ordered = known + extra

    for name in ordered:
        required = name in REQUIRED_COLUMNS
        title = COLUMN_TITLES.get(name, str(name))
        units = COLUMN_UNITS.get(name, "")
        if name not in df.columns:
            if required or name in OPTIONAL_COLUMNS:
                profiles.append(
                    ColumnProfile(
                        name=name,
                        title=title,
                        units=units,
                        required=required,
                        present=False,
                    )
                )
            continue

        series = pd.to_numeric(df[name], errors="coerce") if name in (
            list(REQUIRED_COLUMNS) + list(OPTIONAL_COLUMNS)
        ) else df[name]
        if not isinstance(series, pd.Series):
            series = pd.Series(series)
        # для числовых колонок считаем пропуски по to_numeric
        if name in list(REQUIRED_COLUMNS) + list(OPTIONAL_COLUMNS):
            series = pd.to_numeric(df[name], errors="coerce")
        count = int(len(series))
        missing = int(series.isna().sum()) if series.dtype != object else int(pd.isna(series).sum())
        share = (missing / count) if count else 0.0
        min_v = max_v = mean_v = None
        numeric = pd.to_numeric(series, errors="coerce")
        if numeric.notna().any():
            min_v = float(numeric.min())
            max_v = float(numeric.max())
            mean_v = float(numeric.mean())
        profiles.append(
            ColumnProfile(
                name=str(name),
                title=title,
                units=units,
                required=required,
                present=True,
                count=count,
                missing=missing,
                missing_share=share,
                min_value=min_v,
                max_value=max_v,
                mean_value=mean_v,
            )
        )
    return profiles


def validate_dataframe(
    df: pd.DataFrame,
    *,
    min_points: int = 10,
    max_missing_share: float = 0.05,
    filename: str = "",
    description: str = "",
    meta: dict[str, Any] | None = None,
) -> ValidationResult:
    """Проверить таблицу эксперимента и собрать наглядный отчёт."""
    issues: list[ValidationIssue] = []
    meta = meta or {}

    if df is None or df.empty:
        issues.append(
            ValidationIssue("error", "empty", "Файл пуст или не содержит данных.")
        )
        return ValidationResult(
            ok=False,
            issues=issues,
            filename=filename,
            description=description or "Пустой файл",
            meta=meta,
        )

    n_rows = len(df)
    columns = [str(c) for c in df.columns]
    profiles = _profile_columns(df)

    # описание по умолчанию из meta
    if not description:
        bits = []
        if meta.get("specimen_material"):
            bits.append(str(meta["specimen_material"]))
        if meta.get("lubrication"):
            bits.append(str(meta["lubrication"]))
        if meta.get("load_N") is not None:
            bits.append(f"{meta['load_N']} Н")
        if meta.get("description"):
            description = str(meta["description"])
        elif bits:
            description = ", ".join(bits)
        else:
            description = "Экспериментальный файл машины трения"

    missing_cols = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing_cols:
        issues.append(
            ValidationIssue(
                "error",
                "missing_columns",
                "Отсутствуют обязательные колонки: " + ", ".join(missing_cols),
            )
        )

    if "time_s" in df.columns:
        time = pd.to_numeric(df["time_s"], errors="coerce")
        if time.isna().all():
            issues.append(
                ValidationIssue("error", "time_nan", "Колонка time_s не содержит чисел.")
            )
        else:
            valid_time = time.dropna()
            if len(valid_time) >= 2:
                diffs = np.diff(valid_time.to_numpy())
                if np.any(diffs < 0):
                    issues.append(
                        ValidationIssue(
                            "warning",
                            "time_not_monotonic",
                            "Время не монотонно возрастает.",
                        )
                    )

    if "friction_force_N" in df.columns:
        f = pd.to_numeric(df["friction_force_N"], errors="coerce")
        neg = int((f < 0).sum())
        if neg:
            issues.append(
                ValidationIssue(
                    "error",
                    "negative_friction",
                    f"Обнаружены отрицательные значения силы трения: {neg} шт.",
                )
            )
        zero_share = float((f == 0).mean()) if len(f) else 0.0
        if zero_share > 0.02:
            issues.append(
                ValidationIssue(
                    "warning",
                    "zero_friction",
                    f"Доля нулевых значений силы трения: {zero_share:.1%} "
                    "(возможен обрыв датчика).",
                )
            )

    if "load_N" in df.columns:
        n = pd.to_numeric(df["load_N"], errors="coerce")
        if (n <= 0).any():
            issues.append(
                ValidationIssue(
                    "warning",
                    "nonpositive_load",
                    "Есть нулевая или отрицательная нагрузка — μ на этих точках некорректен.",
                )
            )
        if len(n):
            small = n < (n.median() * 0.3 if n.median() > 0 else 1.0)
            if small.iloc[: min(50, len(n))].mean() > 0.5:
                issues.append(
                    ValidationIssue(
                        "warning",
                        "warmup_load",
                        "В начале опыта нагрузка нестабильна (холостой участок).",
                    )
                )

    if n_rows < min_points:
        issues.append(
            ValidationIssue(
                "error",
                "too_short",
                f"Слишком мало точек: {n_rows} (минимум {min_points}).",
            )
        )

    for col in REQUIRED_COLUMNS:
        if col not in df.columns:
            continue
        share = float(pd.to_numeric(df[col], errors="coerce").isna().mean())
        missing_n = int(pd.to_numeric(df[col], errors="coerce").isna().sum())
        if share > max_missing_share:
            issues.append(
                ValidationIssue(
                    "error",
                    "too_many_missing",
                    f"В колонке {col} слишком много пропусков: {missing_n} шт. ({share:.2%}).",
                )
            )
        elif share > 0:
            issues.append(
                ValidationIssue(
                    "warning",
                    "missing_values",
                    f"В колонке {col} есть пропуски: {missing_n} шт. ({share:.2%}).",
                )
            )

    for col in ("temperature_C", "wear_um", "distance_m", "speed_m_s"):
        if col in df.columns:
            series = pd.to_numeric(df[col], errors="coerce")
            missing_n = int(series.isna().sum())
            share = float(series.isna().mean())
            if missing_n > 0:
                title = COLUMN_TITLES.get(col, col)
                issues.append(
                    ValidationIssue(
                        "warning",
                        "optional_missing",
                        f"В колонке {title} ({col}) есть пропуски: "
                        f"{missing_n} шт. ({share:.2%}).",
                    )
                )

    ok = not any(i.level == "error" for i in issues)
    return ValidationResult(
        ok=ok,
        issues=issues,
        n_rows=n_rows,
        n_cols=len(columns),
        columns=columns,
        profiles=profiles,
        filename=filename,
        description=description,
        meta=meta,
    )
