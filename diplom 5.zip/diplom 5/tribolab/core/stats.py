"""Этап 6. Статистическая обработка результатов."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
import pandas as pd

from .friction import FrictionResult
from .wear import WearResult


def describe_series(series: pd.Series) -> dict[str, float]:
    s = pd.to_numeric(series, errors="coerce").dropna()
    if s.empty:
        return {
            "count": 0,
            "mean": float("nan"),
            "median": float("nan"),
            "std": float("nan"),
            "min": float("nan"),
            "max": float("nan"),
            "cv": float("nan"),
        }
    mean = float(s.mean())
    std = float(s.std(ddof=0))
    return {
        "count": float(len(s)),
        "mean": mean,
        "median": float(s.median()),
        "std": std,
        "min": float(s.min()),
        "max": float(s.max()),
        "cv": float(std / mean) if mean != 0 else float("nan"),
    }


def _t_critical_approx(df: int, confidence: float = 0.95) -> float:
    """Приближение квантиля Стьюдента без SciPy (достаточно для отчёта)."""
    if df <= 0:
        return 1.96
    # грубая аппроксимация для 95%
    if abs(confidence - 0.95) > 1e-6:
        z = 1.96
    else:
        z = 1.96
    # поправка на малую выборку
    return z + 2.0 / max(df, 1)


def confidence_interval_mean(
    series: pd.Series,
    confidence: float = 0.95,
) -> tuple[float, float]:
    """Доверительный интервал среднего."""
    s = pd.to_numeric(series, errors="coerce").dropna().to_numpy(dtype=float)
    n = len(s)
    if n < 2:
        m = float(s.mean()) if n else float("nan")
        return m, m
    mean = float(np.mean(s))
    sem = float(np.std(s, ddof=1) / np.sqrt(n))
    tcrit = _t_critical_approx(n - 1, confidence)
    half = tcrit * sem
    return mean - half, mean + half


@dataclass
class ExperimentSummary:
    name: str
    n_points: int
    mu_mean: float
    mu_mean_steady: float
    mu_std: float
    mu_ci95_low: float
    mu_ci95_high: float
    wear_delta_um: float | None
    wear_rate_um_per_s: float | None
    wear_intensity_um_per_m: float | None
    temp_mean_C: float | None
    temp_max_C: float | None
    load_mean_N: float | None
    duration_s: float | None
    meta: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_rows(self) -> list[tuple[str, str]]:
        rows = [
            ("Имя опыта", self.name),
            ("Число точек", str(self.n_points)),
            ("μ среднее", f"{self.mu_mean:.4f}"),
            ("μ стационарное", f"{self.mu_mean_steady:.4f}"),
            ("μ СКО", f"{self.mu_std:.4f}"),
            ("μ ДИ 95%", f"[{self.mu_ci95_low:.4f}; {self.mu_ci95_high:.4f}]"),
        ]
        if self.wear_delta_um is not None:
            rows.append(("Износ Δh, мкм", f"{self.wear_delta_um:.4f}"))
        if self.wear_rate_um_per_s is not None:
            rows.append(("Скорость изнашивания, мкм/с", f"{self.wear_rate_um_per_s:.6f}"))
        if self.wear_intensity_um_per_m is not None:
            rows.append(
                ("Интенсивность изнашивания, мкм/м", f"{self.wear_intensity_um_per_m:.6f}")
            )
        if self.temp_mean_C is not None:
            rows.append(("Температура средняя, °C", f"{self.temp_mean_C:.2f}"))
        if self.temp_max_C is not None:
            rows.append(("Температура макс., °C", f"{self.temp_max_C:.2f}"))
        if self.load_mean_N is not None:
            rows.append(("Нагрузка средняя, Н", f"{self.load_mean_N:.2f}"))
        if self.duration_s is not None:
            rows.append(("Длительность, с", f"{self.duration_s:.1f}"))
        return rows


def summarize_experiment(
    name: str,
    df: pd.DataFrame,
    friction: FrictionResult,
    wear: WearResult,
    meta: dict[str, Any] | None = None,
) -> ExperimentSummary:
    mu = friction.dataframe["mu"]
    ci_low, ci_high = confidence_interval_mean(mu)

    temp_mean = temp_max = None
    if "temperature_C" in df.columns:
        temp = pd.to_numeric(df["temperature_C"], errors="coerce")
        if temp.notna().any():
            temp_mean = float(temp.mean())
            temp_max = float(temp.max())

    load_mean = None
    if "load_N" in df.columns:
        load = pd.to_numeric(df["load_N"], errors="coerce")
        if load.notna().any():
            load_mean = float(load.mean())

    duration = None
    if "time_s" in df.columns:
        t = pd.to_numeric(df["time_s"], errors="coerce")
        if t.notna().any():
            duration = float(t.max() - t.min())

    return ExperimentSummary(
        name=name,
        n_points=friction.n_points,
        mu_mean=friction.mu_mean,
        mu_mean_steady=friction.mu_mean_steady,
        mu_std=friction.mu_std,
        mu_ci95_low=ci_low,
        mu_ci95_high=ci_high,
        wear_delta_um=wear.wear_delta_um if wear.available else None,
        wear_rate_um_per_s=wear.wear_rate_um_per_s if wear.available else None,
        wear_intensity_um_per_m=wear.wear_intensity_um_per_m if wear.available else None,
        temp_mean_C=temp_mean,
        temp_max_C=temp_max,
        load_mean_N=load_mean,
        duration_s=duration,
        meta=meta or {},
    )
