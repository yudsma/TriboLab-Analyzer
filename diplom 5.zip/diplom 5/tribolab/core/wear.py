"""Этап 5. Расчёт показателей изнашивания."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass
class WearResult:
    wear_initial_um: float
    wear_final_um: float
    wear_delta_um: float
    duration_s: float
    wear_rate_um_per_s: float
    distance_m: float | None
    wear_intensity_um_per_m: float | None
    available: bool
    note: str = ""


def calculate_wear(df: pd.DataFrame) -> WearResult:
    """Рассчитать итоговый износ, скорость и интенсивность изнашивания."""
    if "wear_um" not in df.columns:
        return WearResult(
            wear_initial_um=0.0,
            wear_final_um=0.0,
            wear_delta_um=0.0,
            duration_s=0.0,
            wear_rate_um_per_s=0.0,
            distance_m=None,
            wear_intensity_um_per_m=None,
            available=False,
            note="Колонка wear_um отсутствует.",
        )

    wear = pd.to_numeric(df["wear_um"], errors="coerce").dropna()
    if wear.empty:
        return WearResult(
            wear_initial_um=0.0,
            wear_final_um=0.0,
            wear_delta_um=0.0,
            duration_s=0.0,
            wear_rate_um_per_s=0.0,
            distance_m=None,
            wear_intensity_um_per_m=None,
            available=False,
            note="Нет валидных значений износа.",
        )

    t = pd.to_numeric(df.loc[wear.index, "time_s"], errors="coerce") if "time_s" in df.columns else None
    if t is not None and t.notna().any():
        duration = float(t.max() - t.min())
    else:
        duration = float(max(len(wear) - 1, 1))

    w0 = float(wear.iloc[0])
    w1 = float(wear.iloc[-1])
    delta = w1 - w0
    rate = delta / duration if duration > 0 else 0.0

    distance = None
    intensity = None
    if "distance_m" in df.columns:
        dist = pd.to_numeric(df["distance_m"], errors="coerce").dropna()
        if not dist.empty:
            distance = float(dist.iloc[-1] - dist.iloc[0])
            if distance > 0:
                intensity = delta / distance
    elif "speed_m_s" in df.columns and t is not None and t.notna().any():
        speed = pd.to_numeric(df["speed_m_s"], errors="coerce").dropna()
        if not speed.empty:
            distance = float(speed.mean() * duration)
            if distance > 0:
                intensity = delta / distance

    return WearResult(
        wear_initial_um=w0,
        wear_final_um=w1,
        wear_delta_um=float(delta),
        duration_s=duration,
        wear_rate_um_per_s=float(rate),
        distance_m=None if distance is None else float(distance),
        wear_intensity_um_per_m=None if intensity is None else float(intensity),
        available=True,
        note="Расчёт выполнен по ряду wear_um.",
    )
