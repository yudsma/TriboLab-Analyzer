"""Этап 4. Расчёт коэффициента трения."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass
class FrictionResult:
    dataframe: pd.DataFrame  # исходные + колонка mu
    mu_mean: float
    mu_median: float
    mu_std: float
    mu_min: float
    mu_max: float
    mu_mean_steady: float
    mu_std_steady: float
    steady_from_s: float
    n_points: int


def calculate_friction(
    df: pd.DataFrame,
    *,
    steady_from_s: float | None = None,
    run_in_factor: float = 0.2,
) -> FrictionResult:
    """
    μ(t) = F_тр(t) / N(t)

    steady_from_s — начало стационарного участка.
    Если не задан, берётся доля run_in_factor от длительности опыта.
    """
    out = df.copy()
    f = pd.to_numeric(out["friction_force_N"], errors="coerce")
    n = pd.to_numeric(out["load_N"], errors="coerce")

    with np.errstate(divide="ignore", invalid="ignore"):
        mu = f / n
    mu = mu.replace([np.inf, -np.inf], np.nan)
    # точки с некорректной нагрузкой
    mu = mu.where(n > 1e-9)
    out["mu"] = mu

    valid = mu.dropna()
    if valid.empty:
        raise ValueError("Не удалось рассчитать коэффициент трения: нет валидных точек.")

    t = pd.to_numeric(out.get("time_s"), errors="coerce")
    if steady_from_s is None:
        if t is not None and t.notna().any():
            t_max = float(t.max())
            steady_from_s = t_max * run_in_factor
        else:
            steady_from_s = 0.0

    if t is not None:
        steady_mask = (t >= steady_from_s) & mu.notna()
        steady = mu[steady_mask]
    else:
        steady = valid

    if steady.empty:
        steady = valid

    return FrictionResult(
        dataframe=out,
        mu_mean=float(valid.mean()),
        mu_median=float(valid.median()),
        mu_std=float(valid.std(ddof=0)),
        mu_min=float(valid.min()),
        mu_max=float(valid.max()),
        mu_mean_steady=float(steady.mean()),
        mu_std_steady=float(steady.std(ddof=0)),
        steady_from_s=float(steady_from_s),
        n_points=int(valid.shape[0]),
    )
