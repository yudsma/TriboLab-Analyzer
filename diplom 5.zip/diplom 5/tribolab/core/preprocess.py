"""Этап 3. Предварительная обработка измерительных данных."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class PreprocessConfig:
    drop_na: bool = True
    interpolate: bool = True
    outlier_method: str = "iqr"  # "iqr" | "zscore" | "none"
    outlier_action: str = "clip"  # "clip" | "remove" | "nan"
    iqr_k: float = 1.5
    zscore_k: float = 3.0
    smooth_method: str = "moving_average"  # "moving_average" | "median" | "none"
    smooth_window: int = 5
    time_from: float | None = None
    time_to: float | None = None
    columns: tuple[str, ...] = (
        "friction_force_N",
        "load_N",
        "temperature_C",
        "wear_um",
    )


@dataclass
class PreprocessResult:
    dataframe: pd.DataFrame
    steps: list[str] = field(default_factory=list)
    removed_rows: int = 0
    outliers_touched: int = 0


def _outlier_mask(series: pd.Series, method: str, iqr_k: float, zscore_k: float) -> pd.Series:
    s = pd.to_numeric(series, errors="coerce")
    if method == "none" or s.notna().sum() < 8:
        return pd.Series(False, index=series.index)

    if method == "zscore":
        mu = s.mean()
        sigma = s.std(ddof=0)
        if sigma == 0 or np.isnan(sigma):
            return pd.Series(False, index=series.index)
        return (s - mu).abs() > zscore_k * sigma

    # IQR
    q1 = s.quantile(0.25)
    q3 = s.quantile(0.75)
    iqr = q3 - q1
    if iqr == 0 or np.isnan(iqr):
        return pd.Series(False, index=series.index)
    low = q1 - iqr_k * iqr
    high = q3 + iqr_k * iqr
    return (s < low) | (s > high)


def _smooth(series: pd.Series, method: str, window: int) -> pd.Series:
    s = pd.to_numeric(series, errors="coerce")
    w = max(3, int(window))
    if w % 2 == 0:
        w += 1
    if method == "none" or len(s) < w:
        return s
    if method == "median":
        return s.rolling(window=w, center=True, min_periods=1).median()
    return s.rolling(window=w, center=True, min_periods=1).mean()


def preprocess(df: pd.DataFrame, config: PreprocessConfig | None = None) -> PreprocessResult:
    """Очистить и подготовить ряд к расчётам."""
    cfg = config or PreprocessConfig()
    steps: list[str] = []
    out = df.copy()
    removed = 0
    outliers_touched = 0

    # обрезка по времени
    if "time_s" in out.columns and (cfg.time_from is not None or cfg.time_to is not None):
        t = pd.to_numeric(out["time_s"], errors="coerce")
        mask = pd.Series(True, index=out.index)
        if cfg.time_from is not None:
            mask &= t >= cfg.time_from
        if cfg.time_to is not None:
            mask &= t <= cfg.time_to
        before = len(out)
        out = out.loc[mask].reset_index(drop=True)
        removed += before - len(out)
        steps.append(
            f"Обрезка по времени: [{cfg.time_from}, {cfg.time_to}], "
            f"удалено строк: {before - len(out)}"
        )

    # интерполяция / удаление пропусков
    work_cols = [c for c in cfg.columns if c in out.columns]
    if cfg.interpolate:
        for col in work_cols + (["time_s"] if "time_s" in out.columns else []):
            if col in out.columns:
                out[col] = pd.to_numeric(out[col], errors="coerce")
                out[col] = out[col].interpolate(method="linear", limit_direction="both")
        steps.append("Линейная интерполяция пропусков")

    if cfg.drop_na:
        subset = [c for c in ("time_s", "friction_force_N", "load_N") if c in out.columns]
        before = len(out)
        out = out.dropna(subset=subset).reset_index(drop=True)
        removed += before - len(out)
        if before != len(out):
            steps.append(f"Удалены строки с пропусками в обязательных колонках: {before - len(out)}")

    # выбросы
    if cfg.outlier_method != "none":
        for col in work_cols:
            if col not in out.columns:
                continue
            mask = _outlier_mask(out[col], cfg.outlier_method, cfg.iqr_k, cfg.zscore_k)
            n = int(mask.sum())
            if n == 0:
                continue
            outliers_touched += n
            if cfg.outlier_action == "remove":
                out = out.loc[~mask].reset_index(drop=True)
                removed += n
            elif cfg.outlier_action == "nan":
                out.loc[mask, col] = np.nan
                out[col] = out[col].interpolate(method="linear", limit_direction="both")
            else:  # clip to whiskers / z-bounds approx via quantile
                s = pd.to_numeric(out[col], errors="coerce")
                q1, q3 = s.quantile(0.25), s.quantile(0.75)
                iqr = q3 - q1
                low, high = q1 - cfg.iqr_k * iqr, q3 + cfg.iqr_k * iqr
                out[col] = s.clip(lower=low, upper=high)
            steps.append(
                f"Выбросы в {col}: метод={cfg.outlier_method}, "
                f"действие={cfg.outlier_action}, затронуто={n}"
            )

    # сглаживание
    if cfg.smooth_method != "none":
        for col in work_cols:
            if col not in out.columns:
                continue
            # износ лучше не «размазывать» агрессивно, но учебный вариант — сглаживаем
            out[col] = _smooth(out[col], cfg.smooth_method, cfg.smooth_window)
        steps.append(
            f"Сглаживание: метод={cfg.smooth_method}, окно={cfg.smooth_window}"
        )

    if not steps:
        steps.append("Обработка не применялась (параметры по умолчанию не изменили ряд)")

    return PreprocessResult(
        dataframe=out,
        steps=steps,
        removed_rows=removed,
        outliers_touched=outliers_touched,
    )
