"""Этап 1. Загрузка экспериментальных данных."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pandas as pd

REQUIRED_COLUMNS = ("time_s", "friction_force_N", "load_N")
OPTIONAL_COLUMNS = ("temperature_C", "wear_um", "distance_m", "speed_m_s")
KNOWN_COLUMNS = REQUIRED_COLUMNS + OPTIONAL_COLUMNS

# Частые синонимы колонок со стендов
COLUMN_ALIASES = {
    "time": "time_s",
    "t": "time_s",
    "time_sec": "time_s",
    "время": "time_s",
    "friction": "friction_force_N",
    "friction_force": "friction_force_N",
    "f_friction": "friction_force_N",
    "force": "friction_force_N",
    "сила_трения": "friction_force_N",
    "load": "load_N",
    "normal_force": "load_N",
    "n_force": "load_N",
    "нагрузка": "load_N",
    "temperature": "temperature_C",
    "temp": "temperature_C",
    "температура": "temperature_C",
    "wear": "wear_um",
    "износ": "wear_um",
    "distance": "distance_m",
    "path": "distance_m",
    "speed": "speed_m_s",
    "velocity": "speed_m_s",
}


@dataclass
class ExperimentData:
    """Загруженный эксперимент."""

    path: Path
    dataframe: pd.DataFrame
    meta: dict[str, Any] = field(default_factory=dict)
    name: str = ""

    def __post_init__(self) -> None:
        if not self.name:
            self.name = self.path.stem


def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    renamed: dict[str, str] = {}
    for col in df.columns:
        key = str(col).strip()
        lower = key.lower()
        if key in KNOWN_COLUMNS:
            renamed[col] = key
        elif lower in COLUMN_ALIASES:
            renamed[col] = COLUMN_ALIASES[lower]
        elif lower in {c.lower() for c in KNOWN_COLUMNS}:
            # точное совпадение без учёта регистра
            for known in KNOWN_COLUMNS:
                if known.lower() == lower:
                    renamed[col] = known
                    break
        else:
            renamed[col] = key
    out = df.rename(columns=renamed)
    # убрать дубликаты имён колонок (оставить первое)
    out = out.loc[:, ~out.columns.duplicated()]
    return out


def _detect_separator(sample: str) -> str:
    semicolons = sample.count(";")
    commas = sample.count(",")
    tabs = sample.count("\t")
    if tabs > semicolons and tabs > commas:
        return "\t"
    if semicolons >= commas:
        return ";"
    return ","


def _read_csv(path: Path) -> pd.DataFrame:
    raw = path.read_bytes()
    text = None
    for enc in ("utf-8-sig", "utf-8", "cp1251"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        text = raw.decode("utf-8", errors="replace")

    sep = _detect_separator("\n".join(text.splitlines()[:5]))
    from io import StringIO

    df = pd.read_csv(StringIO(text), sep=sep)
    return df


def load_meta(path: Path | None) -> dict[str, Any]:
    """Загрузить JSON-метаданные опыта."""
    if path is None or not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def find_meta_for(data_path: Path, meta_dir: Path | None = None) -> Path | None:
    """Найти meta JSON рядом с файлом или в examples/meta."""
    candidates = [
        data_path.with_suffix(".json"),
        data_path.parent / f"{data_path.stem}.json",
    ]
    if meta_dir is not None:
        candidates.append(meta_dir / f"{data_path.stem}.json")

    for parent in data_path.resolve().parents:
        candidates.append(parent / "meta" / f"{data_path.stem}.json")
        candidates.append(parent / "examples" / "meta" / f"{data_path.stem}.json")
        if parent.name.lower() in {"diplom 5", "tribolab-analyzer"}:
            break

    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def load_experiment(
    path: str | Path,
    meta_path: str | Path | None = None,
) -> ExperimentData:
    """Загрузить эксперимент из CSV или XLSX."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Файл не найден: {path}")

    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xls"}:
        df = pd.read_excel(path)
    elif suffix in {".csv", ".txt", ".dat"}:
        df = _read_csv(path)
    else:
        raise ValueError(f"Неподдерживаемый формат файла: {suffix}")

    df = _normalize_columns(df)
    # привести известные колонки к числу
    for col in df.columns:
        if col in KNOWN_COLUMNS:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    resolved_meta: Path | None
    if meta_path is not None:
        resolved_meta = Path(meta_path)
    else:
        resolved_meta = find_meta_for(path)

    meta = load_meta(resolved_meta)
    return ExperimentData(path=path, dataframe=df, meta=meta, name=path.stem)
