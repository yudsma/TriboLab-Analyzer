"""TriboLab Analyzer — обработка результатов трибологического эксперимента."""

__version__ = "1.0.0"
__app_name__ = "TriboLab Analyzer"
