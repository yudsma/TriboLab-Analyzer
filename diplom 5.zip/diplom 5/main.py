"""Точка входа TriboLab Analyzer."""

from __future__ import annotations

import sys
from pathlib import Path

# чтобы пакет tribolab находился при запуске из корня проекта
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tribolab.ui.main_window import run_app


def main() -> int:
    return run_app()


if __name__ == "__main__":
    raise SystemExit(main())
