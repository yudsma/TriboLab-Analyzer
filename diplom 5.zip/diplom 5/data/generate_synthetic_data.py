"""
Генератор учебных данных трибологических испытаний (pin-on-disk / блок-на-кольце).
Данные синтетические, но по характеру близки к реальным рядам машины трения.
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "examples" / "raw"
META = ROOT / "examples" / "meta"
EXPECTED = ROOT / "examples" / "expected"

RNG = np.random.default_rng(42)


def friction_series(
    t: np.ndarray,
    *,
    load_n: float,
    mu_run_in: float,
    mu_steady: float,
    run_in_s: float,
    noise_std: float,
    stick_slip_amp: float = 0.0,
    stick_slip_freq: float = 0.0,
) -> np.ndarray:
    """Сила трения: приработка → стационарный режим + шум/осцилляции."""
    # переход приработки: экспоненциальный спад/рост к стационару
    blend = 1.0 - np.exp(-t / max(run_in_s, 1e-6))
    mu = mu_run_in + (mu_steady - mu_run_in) * blend

    # слабый низкочастотный дрейф
    drift = 0.01 * mu_steady * np.sin(2 * math.pi * t / (t[-1] * 0.7 + 1))

    # stick-slip / вибрации
    osc = stick_slip_amp * np.sin(2 * math.pi * stick_slip_freq * t)

    noise = RNG.normal(0.0, noise_std, size=t.shape)
    mu_inst = np.clip(mu + drift + osc + noise, 0.02, 1.2)
    return mu_inst * load_n


def temperature_series(
    t: np.ndarray,
    *,
    t0: float,
    rise: float,
    tau: float,
    noise_std: float = 0.15,
) -> np.ndarray:
    temp = t0 + rise * (1.0 - np.exp(-t / tau))
    return temp + RNG.normal(0.0, noise_std, size=t.shape)


def wear_series(
    t: np.ndarray,
    *,
    speed_m_s: float,
    k_wear: float,
    load_n: float,
    noise_std: float = 0.05,
) -> np.ndarray:
    """Линейный износ, мкм: примерно пропорционален пути * нагрузке."""
    distance_m = speed_m_s * t
    # k_wear в мкм / (Н·м)
    wear = k_wear * load_n * distance_m
    # чуть быстрее в приработке
    wear = wear + 0.15 * wear * np.exp(-t / 120.0)
    wear = wear + np.maximum.accumulate(RNG.normal(0.0, noise_std, size=t.shape))
    return np.maximum(wear, 0.0)


def inject_defects(
    df: pd.DataFrame,
    *,
    n_outliers: int = 8,
    n_nans: int = 5,
    drop_load_start: bool = True,
) -> pd.DataFrame:
    out = df.copy()
    n = len(out)

    if drop_load_start:
        # холостой участок: нагрузка ещё не установилась
        warm = min(25, n // 40)
        out.loc[: warm - 1, "load_N"] = RNG.uniform(2, 12, size=warm)
        out.loc[: warm - 1, "friction_force_N"] *= RNG.uniform(0.2, 0.6, size=warm)

    idx_out = RNG.choice(np.arange(40, n - 10), size=n_outliers, replace=False)
    out.loc[idx_out, "friction_force_N"] *= RNG.uniform(2.5, 4.5, size=n_outliers)

    idx_nan = RNG.choice(np.arange(50, n - 10), size=n_nans, replace=False)
    out.loc[idx_nan, "temperature_C"] = np.nan

    # один короткий «обрыв» датчика силы
    glitch_start = int(n * 0.55)
    out.loc[glitch_start : glitch_start + 2, "friction_force_N"] = 0.0

    return out


def make_experiment(cfg: dict) -> tuple[pd.DataFrame, dict, dict]:
    dt = cfg["dt_s"]
    duration = cfg["duration_s"]
    t = np.arange(0.0, duration + 1e-12, dt)

    load = np.full_like(t, cfg["load_N"], dtype=float)
    # небольшая пульсация нагрузки
    load = load + RNG.normal(0.0, cfg.get("load_noise", 0.4), size=t.shape)
    load = np.clip(load, cfg["load_N"] * 0.9, cfg["load_N"] * 1.1)

    f = friction_series(
        t,
        load_n=cfg["load_N"],
        mu_run_in=cfg["mu_run_in"],
        mu_steady=cfg["mu_steady"],
        run_in_s=cfg["run_in_s"],
        noise_std=cfg["mu_noise"],
        stick_slip_amp=cfg.get("stick_slip_amp", 0.0),
        stick_slip_freq=cfg.get("stick_slip_freq", 0.0),
    )
    # пересчёт с учётом мгновенной нагрузки для чуть большей реалистичности
    mu_inst = f / cfg["load_N"]
    f = mu_inst * load

    temp = temperature_series(
        t,
        t0=cfg["temp0_C"],
        rise=cfg["temp_rise_C"],
        tau=cfg["temp_tau_s"],
    )
    wear = wear_series(
        t,
        speed_m_s=cfg["speed_m_s"],
        k_wear=cfg["k_wear"],
        load_n=cfg["load_N"],
    )
    distance = cfg["speed_m_s"] * t

    df = pd.DataFrame(
        {
            "time_s": np.round(t, 3),
            "friction_force_N": np.round(f, 4),
            "load_N": np.round(load, 4),
            "temperature_C": np.round(temp, 3),
            "wear_um": np.round(wear, 4),
            "distance_m": np.round(distance, 4),
            "speed_m_s": np.round(np.full_like(t, cfg["speed_m_s"]), 4),
        }
    )

    if cfg.get("with_defects", True):
        df = inject_defects(df)

    # эталонные показатели по «чистому» стационарному участку (для главы 6)
    steady_mask = df["time_s"] >= cfg["run_in_s"] * 1.5
    mu_series = df["friction_force_N"] / df["load_N"]
    mu_steady = mu_series[steady_mask].replace([np.inf, -np.inf], np.nan).dropna()

    expected = {
        "experiment_id": cfg["id"],
        "mu_mean_steady_approx": float(np.round(mu_steady.mean(), 4)),
        "mu_std_steady_approx": float(np.round(mu_steady.std(), 4)),
        "wear_final_um_approx": float(df["wear_um"].iloc[-1]),
        "temp_max_C_approx": float(df["temperature_C"].max(skipna=True)),
        "n_points": int(len(df)),
        "note": "Оценки приблизительные: в сырых файлах есть выбросы и пропуски.",
    }

    meta = {
        "experiment_id": cfg["id"],
        "machine_type": cfg["machine_type"],
        "contact_scheme": cfg["contact_scheme"],
        "specimen_material": cfg["specimen_material"],
        "counterbody_material": cfg["counterbody_material"],
        "lubrication": cfg["lubrication"],
        "load_N": cfg["load_N"],
        "speed_m_s": cfg["speed_m_s"],
        "duration_s": cfg["duration_s"],
        "sampling_hz": round(1.0 / cfg["dt_s"], 3),
        "operator": cfg["operator"],
        "date": cfg["date"],
        "lab": "Учебная лаборатория триботехники (синтетический набор)",
        "units": {
            "time_s": "s",
            "friction_force_N": "N",
            "load_N": "N",
            "temperature_C": "C",
            "wear_um": "um",
            "distance_m": "m",
            "speed_m_s": "m/s",
        },
        "columns_required": ["time_s", "friction_force_N", "load_N"],
        "columns_optional": ["temperature_C", "wear_um", "distance_m", "speed_m_s"],
        "data_origin": "synthetic",
        "description": cfg["description"],
    }
    return df, meta, expected


EXPERIMENTS = [
    {
        "id": "EXP01_steel_dry_50N",
        "filename": "EXP01_steel_dry_50N.csv",
        "machine_type": "МТУ-1 (учебный аналог pin-on-disk)",
        "contact_scheme": "палец–диск",
        "specimen_material": "Сталь 45",
        "counterbody_material": "Сталь ШХ15",
        "lubrication": "без смазки",
        "load_N": 50.0,
        "speed_m_s": 0.25,
        "duration_s": 600.0,
        "dt_s": 0.2,
        "mu_run_in": 0.42,
        "mu_steady": 0.55,
        "run_in_s": 80.0,
        "mu_noise": 0.025,
        "stick_slip_amp": 0.03,
        "stick_slip_freq": 1.7,
        "temp0_C": 23.0,
        "temp_rise_C": 28.0,
        "temp_tau_s": 180.0,
        "k_wear": 0.00035,
        "operator": "Иванов А.С.",
        "date": "2026-02-10",
        "description": "Сухое трение, умеренная нагрузка, выраженная приработка.",
        "with_defects": True,
    },
    {
        "id": "EXP02_steel_oil_50N",
        "filename": "EXP02_steel_oil_50N.csv",
        "machine_type": "МТУ-1 (учебный аналог pin-on-disk)",
        "contact_scheme": "палец–диск",
        "specimen_material": "Сталь 45",
        "counterbody_material": "Сталь ШХ15",
        "lubrication": "масло И-20А",
        "load_N": 50.0,
        "speed_m_s": 0.25,
        "duration_s": 600.0,
        "dt_s": 0.2,
        "mu_run_in": 0.18,
        "mu_steady": 0.12,
        "run_in_s": 60.0,
        "mu_noise": 0.008,
        "stick_slip_amp": 0.005,
        "stick_slip_freq": 0.8,
        "temp0_C": 23.0,
        "temp_rise_C": 12.0,
        "temp_tau_s": 220.0,
        "k_wear": 0.00008,
        "operator": "Иванов А.С.",
        "date": "2026-02-10",
        "description": "Тот же режим, но со смазкой — для сравнения с EXP01.",
        "with_defects": True,
    },
    {
        "id": "EXP03_steel_oil_100N",
        "filename": "EXP03_steel_oil_100N.csv",
        "machine_type": "МТУ-1 (учебный аналог pin-on-disk)",
        "contact_scheme": "палец–диск",
        "specimen_material": "Сталь 45",
        "counterbody_material": "Сталь ШХ15",
        "lubrication": "масло И-20А",
        "load_N": 100.0,
        "speed_m_s": 0.25,
        "duration_s": 600.0,
        "dt_s": 0.2,
        "mu_run_in": 0.16,
        "mu_steady": 0.14,
        "run_in_s": 70.0,
        "mu_noise": 0.01,
        "stick_slip_amp": 0.008,
        "stick_slip_freq": 1.1,
        "temp0_C": 23.5,
        "temp_rise_C": 18.0,
        "temp_tau_s": 200.0,
        "k_wear": 0.00011,
        "operator": "Петрова Е.В.",
        "date": "2026-02-12",
        "description": "Смазка, повышенная нагрузка 100 Н.",
        "with_defects": True,
    },
    {
        "id": "EXP04_bronze_dry_40N",
        "filename": "EXP04_bronze_dry_40N.csv",
        "machine_type": "МТУ-1 (учебный аналог pin-on-disk)",
        "contact_scheme": "палец–диск",
        "specimen_material": "Бронза БрОЦС5-5-5",
        "counterbody_material": "Сталь 45",
        "lubrication": "без смазки",
        "load_N": 40.0,
        "speed_m_s": 0.15,
        "duration_s": 480.0,
        "dt_s": 0.25,
        "mu_run_in": 0.28,
        "mu_steady": 0.22,
        "run_in_s": 90.0,
        "mu_noise": 0.015,
        "stick_slip_amp": 0.012,
        "stick_slip_freq": 0.9,
        "temp0_C": 22.0,
        "temp_rise_C": 15.0,
        "temp_tau_s": 160.0,
        "k_wear": 0.00022,
        "operator": "Петрова Е.В.",
        "date": "2026-02-14",
        "description": "Другая пара трения (бронза–сталь), сухое трение.",
        "with_defects": True,
    },
    {
        "id": "EXP05_coating_oil_80N",
        "filename": "EXP05_coating_oil_80N.csv",
        "machine_type": "МТУ-1 (учебный аналог pin-on-disk)",
        "contact_scheme": "палец–диск",
        "specimen_material": "Сталь 40Х + покрытие TiN",
        "counterbody_material": "Сталь ШХ15",
        "lubrication": "масло И-20А",
        "load_N": 80.0,
        "speed_m_s": 0.30,
        "duration_s": 720.0,
        "dt_s": 0.2,
        "mu_run_in": 0.14,
        "mu_steady": 0.09,
        "run_in_s": 50.0,
        "mu_noise": 0.006,
        "stick_slip_amp": 0.004,
        "stick_slip_freq": 1.4,
        "temp0_C": 24.0,
        "temp_rise_C": 10.0,
        "temp_tau_s": 240.0,
        "k_wear": 0.00004,
        "operator": "Сидоров М.И.",
        "date": "2026-02-18",
        "description": "Покрытый образец: низкий μ и малый износ.",
        "with_defects": True,
    },
    {
        "id": "EXP06_short_clean_demo",
        "filename": "EXP06_short_clean_demo.csv",
        "machine_type": "МТУ-1 (учебный аналог pin-on-disk)",
        "contact_scheme": "палец–диск",
        "specimen_material": "Сталь 45",
        "counterbody_material": "Сталь ШХ15",
        "lubrication": "масло И-20А",
        "load_N": 100.0,
        "speed_m_s": 0.2,
        "duration_s": 120.0,
        "dt_s": 0.5,
        "mu_run_in": 0.15,
        "mu_steady": 0.15,
        "run_in_s": 10.0,
        "mu_noise": 0.002,
        "temp0_C": 25.0,
        "temp_rise_C": 3.0,
        "temp_tau_s": 60.0,
        "k_wear": 0.00005,
        "operator": "demo",
        "date": "2026-03-01",
        "description": "Короткий чистый файл без дефектов — для ручной проверки μ в Excel.",
        "with_defects": False,
    },
]


def write_bad_files() -> None:
    """Файлы с ошибками для тестирования валидатора (глава 6)."""
    # нет колонки нагрузки
    pd.DataFrame(
        {
            "time_s": [0, 1, 2],
            "friction_force_N": [10, 11, 12],
            "temperature_C": [25, 26, 27],
        }
    ).to_csv(RAW / "BAD01_missing_load.csv", index=False, sep=";")

    # отрицательная сила трения
    pd.DataFrame(
        {
            "time_s": [0.0, 0.2, 0.4, 0.6],
            "friction_force_N": [12.0, -5.0, 13.0, 12.5],
            "load_N": [50, 50, 50, 50],
            "temperature_C": [24, 24, 25, 25],
            "wear_um": [0, 0.01, 0.02, 0.03],
        }
    ).to_csv(RAW / "BAD02_negative_friction.csv", index=False, sep=";")

    # слишком мало точек
    pd.DataFrame(
        {
            "time_s": [0.0, 1.0],
            "friction_force_N": [10.0, 11.0],
            "load_N": [50.0, 50.0],
        }
    ).to_csv(RAW / "BAD03_too_short.csv", index=False, sep=";")


def main() -> None:
    RAW.mkdir(parents=True, exist_ok=True)
    META.mkdir(parents=True, exist_ok=True)
    EXPECTED.mkdir(parents=True, exist_ok=True)

    catalog = []
    all_expected = {}

    for cfg in EXPERIMENTS:
        df, meta, expected = make_experiment(cfg)
        path = RAW / cfg["filename"]
        # как часто бывает у стендов в РФ — CSV с ';'
        df.to_csv(path, index=False, sep=";", encoding="utf-8")

        meta_path = META / f"{cfg['id']}.json"
        meta_path.write_text(
            json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        all_expected[cfg["id"]] = expected
        catalog.append(
            {
                "id": cfg["id"],
                "file": f"raw/{cfg['filename']}",
                "meta": f"meta/{cfg['id']}.json",
                "points": len(df),
                "material": cfg["specimen_material"],
                "lubrication": cfg["lubrication"],
                "load_N": cfg["load_N"],
            }
        )
        print(f"OK {cfg['filename']}: {len(df)} rows")

    write_bad_files()
    print("OK BAD01..BAD03")

    (EXPECTED / "reference_metrics.json").write_text(
        json.dumps(all_expected, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (ROOT / "examples" / "dataset_catalog.json").write_text(
        json.dumps(
            {
                "title": "Учебный набор данных трибологических испытаний",
                "origin": "synthetic",
                "purpose": "Дипломный проект: обработка результатов трибологического эксперимента",
                "separator": ";",
                "encoding": "utf-8",
                "experiments": catalog,
                "bad_files_for_validation_tests": [
                    "raw/BAD01_missing_load.csv",
                    "raw/BAD02_negative_friction.csv",
                    "raw/BAD03_too_short.csv",
                ],
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    # отдельный Excel для демонстрации импорта xlsx
    demo = pd.read_csv(RAW / "EXP06_short_clean_demo.csv", sep=";")
    demo.to_excel(RAW / "EXP06_short_clean_demo.xlsx", index=False)
    print("OK EXP06_short_clean_demo.xlsx")


if __name__ == "__main__":
    main()
