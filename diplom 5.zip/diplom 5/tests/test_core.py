from __future__ import annotations

from pathlib import Path

import pandas as pd
import pytest

from tribolab.core.compare import compare_experiments
from tribolab.core.friction import calculate_friction
from tribolab.core.pipeline import process_experiment
from tribolab.core.preprocess import PreprocessConfig, preprocess
from tribolab.core.validator import validate_dataframe
from tribolab.core.wear import calculate_wear
from tribolab.io.loader import load_experiment

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "examples" / "raw"


def test_load_exp02():
    exp = load_experiment(RAW / "EXP02_steel_oil_50N.csv")
    assert len(exp.dataframe) > 1000
    assert {"time_s", "friction_force_N", "load_N"}.issubset(exp.dataframe.columns)
    assert exp.meta.get("lubrication") == "масло И-20А"


def test_validate_ok_and_bad():
    ok = load_experiment(RAW / "EXP06_short_clean_demo.csv")
    result_ok = validate_dataframe(ok.dataframe)
    assert result_ok.ok

    bad = load_experiment(RAW / "BAD01_missing_load.csv")
    result_bad = validate_dataframe(bad.dataframe)
    assert not result_bad.ok
    assert any(i.code == "missing_columns" for i in result_bad.errors)

    bad2 = load_experiment(RAW / "BAD02_negative_friction.csv")
    assert not validate_dataframe(bad2.dataframe).ok

    bad3 = load_experiment(RAW / "BAD03_too_short.csv")
    assert not validate_dataframe(bad3.dataframe).ok


def test_friction_reference_exp06():
    exp = load_experiment(RAW / "EXP06_short_clean_demo.csv")
    prep = preprocess(
        exp.dataframe,
        PreprocessConfig(outlier_method="none", smooth_method="none"),
    )
    fr = calculate_friction(prep.dataframe, steady_from_s=10.0)
    assert fr.mu_mean == pytest.approx(0.15, abs=0.02)
    assert fr.mu_mean_steady == pytest.approx(0.15, abs=0.02)


def test_wear_positive():
    exp = load_experiment(RAW / "EXP02_steel_oil_50N.csv")
    wear = calculate_wear(exp.dataframe)
    assert wear.available
    assert wear.wear_delta_um > 0
    assert wear.wear_rate_um_per_s > 0


def test_preprocess_reduces_extreme_spikes():
    exp = load_experiment(RAW / "EXP01_steel_dry_50N.csv")
    raw_max = float(exp.dataframe["friction_force_N"].max())
    prep = preprocess(
        exp.dataframe,
        PreprocessConfig(
            outlier_method="iqr",
            outlier_action="clip",
            smooth_method="moving_average",
            smooth_window=7,
        ),
    )
    new_max = float(prep.dataframe["friction_force_N"].max())
    assert new_max <= raw_max
    assert prep.outliers_touched >= 0


def test_pipeline_and_compare(tmp_path: Path):
    p1 = process_experiment(
        RAW / "EXP01_steel_dry_50N.csv",
        plots_dir=tmp_path / "p1",
        export_dir=tmp_path / "r1",
    )
    p2 = process_experiment(
        RAW / "EXP02_steel_oil_50N.csv",
        plots_dir=tmp_path / "p2",
        export_dir=tmp_path / "r2",
    )
    assert p1.summary is not None and p2.summary is not None
    assert p1.summary.mu_mean_steady > p2.summary.mu_mean_steady
    table = compare_experiments([p1.summary, p2.summary])
    assert len(table) == 2
    assert (tmp_path / "r2" / "EXP02_steel_oil_50N_report.xlsx").exists()
    assert (tmp_path / "r2" / "EXP02_steel_oil_50N_report.pdf").exists()


def test_load_xlsx():
    exp = load_experiment(RAW / "EXP06_short_clean_demo.xlsx")
    assert len(exp.dataframe) > 10
